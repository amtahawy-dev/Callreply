@echo off
setlocal
cd /d "%~dp0"
echo ========================================
echo CallReply - Build Debug APK
echo ========================================
where java >nul 2>nul || (echo ERROR: Java is not installed or not on PATH.& pause & exit /b 1)
where gradle >nul 2>nul || (echo ERROR: Gradle command not found.& echo Open this folder in Android Studio, allow Gradle Sync, then use Build ^> Build APK(s).& pause & exit /b 1)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" echo WARNING: ANDROID_HOME/ANDROID_SDK_ROOT is not set. Gradle may still find the SDK via Android Studio.
gradle --no-daemon :app:assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the error text and send it for troubleshooting.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCESS.
echo APK: %CD%\app\build\outputs\apk\debug\app-debug.apk
pause
