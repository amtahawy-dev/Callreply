package com.example.callreply

import android.Manifest
import android.app.role.RoleManager
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var listBox: LinearLayout
    private lateinit var logBox: LinearLayout
    private val replyNames = arrayOf("حسب الخط المرسِل العام", "الخط 1 دايماً", "الخط 2 دايماً")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setContentView(ScrollView(this).apply { addView(root) })

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun edit(h: String) = EditText(this).apply { hint = h }
        fun title(t: String) = TextView(this).apply { text = "\n$t"; textSize = 16f }

        root.addView(btn("1) إعطاء الصلاحيات") { askPermissions() })
        root.addView(btn("2) تفعيل التطبيق كمُصفّي مكالمات") { askRole() })

        root.addView(title("الرسالة الافتراضية"))
        val msg = edit("الرسالة").apply { setText(store.defaultMessage) }
        root.addView(msg)

        root.addView(TextView(this).apply { text = "أقل وقت بين رسالتين لنفس الرقم (دقايق)" })
        val cd = edit("60").apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(store.cooldownMin.toString())
        }
        root.addView(cd)

        // إعدادات كل خط
        val savers = mutableListOf<() -> Unit>()
        for (slot in 0..1) {
            root.addView(title("الخط ${slot + 1}"))
            val sw = Switch(this).apply {
                text = "تفعيل الرفض والرد على الخط ${slot + 1}"
                isChecked = store.simEnabled(slot)
            }
            val m = edit("رسالة الخط ${slot + 1} (فاضية = الافتراضية)")
                .apply { setText(store.simMessage(slot)) }
            root.addView(sw); root.addView(m)
            savers += { store.setSimEnabled(slot, sw.isChecked); store.setSimMessage(slot, m.text.toString()) }
        }

        root.addView(title("قنوات الرد"))
        val smsSw = Switch(this).apply { text = "إرسال SMS تلقائي"; isChecked = store.smsEnabled }
        val waSw = Switch(this).apply {
            text = "إشعار واتساب بعد الرفض (بضغطة)"; isChecked = store.waNotify
        }
        val cc = edit("كود الدولة (مصر 20)").apply {
            inputType = InputType.TYPE_CLASS_NUMBER; setText(store.countryCode)
        }
        root.addView(smsSw); root.addView(waSw); root.addView(cc)

        root.addView(title("الخط المرسِل للرسايل (اللي عليه رصيد)"))
        val sender = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("نفس الخط اللي اتصل عليه", "الخط 1", "الخط 2")
            )
            setSelection(store.senderSlot + 1)
        }
        root.addView(sender)

        root.addView(btn("حفظ الإعدادات") {
            store.defaultMessage = msg.text.toString()
            store.cooldownMin = cd.text.toString().toIntOrNull() ?: 60
            store.senderSlot = sender.selectedItemPosition - 1
            store.smsEnabled = smsSw.isChecked
            store.waNotify = waSw.isChecked
            store.countryCode = cc.text.toString().ifBlank { "20" }
            savers.forEach { it() }
            toast("تم الحفظ")
        })

        root.addView(title("إضافة رقم"))
        val num = edit("الرقم").apply { inputType = InputType.TYPE_CLASS_PHONE }
        val own = edit("رسالة خاصة بالرقم ده (اختياري)")
        val from = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, replyNames)
        }
        root.addView(num); root.addView(own)
        root.addView(TextView(this).apply { text = "الرد من:" })
        root.addView(from)
        root.addView(btn("إضافة") {
            val n = num.text.toString().trim()
            if (normalize(n).length < 7) { toast("رقم غير صحيح"); return@btn }
            val list = store.rules().filter { normalize(it.number) != normalize(n) }.toMutableList()
            list.add(Rule(n, own.text.toString().trim(), from.selectedItemPosition - 1))
            store.saveRules(list)
            num.text.clear(); own.text.clear(); from.setSelection(0)
            refresh()
        })

        root.addView(title("الأرقام المحظورة"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        refresh()

        root.addView(title("السجل"))
        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(logBox)
        root.addView(btn("مسح السجل") { store.clearLogs(); refreshLog() })
        refreshLog()
    }

    override fun onResume() {
        super.onResume()
        if (::logBox.isInitialized) refreshLog()
    }

    private fun refreshLog() {
        logBox.removeAllViews()
        val fmt = SimpleDateFormat("d/M HH:mm", Locale.getDefault())
        val logs = store.logs()
        if (logs.isEmpty()) {
            logBox.addView(TextView(this).apply { text = "لسه مفيش سجل" })
            return
        }
        logs.take(50).forEach { e ->
            val what = when (e.event) {
                "rejected" -> "🚫 اترفضت" + if (e.line >= 0) " على الخط ${e.line + 1}" else ""
                "sms_sent" -> "✉️ SMS اتبعتت" + if (e.line >= 0) " من الخط ${e.line + 1}" else ""
                "sms_failed" -> "⚠️ فشل إرسال SMS (راجع الرصيد)"
                "cooldown" -> "⏳ مفيش SMS (الحد الأدنى)"
                "wa_notified" -> "💚 إشعار واتساب اتعرض"
                else -> e.event
            }
            logBox.addView(TextView(this).apply {
                text = "${fmt.format(Date(e.time))}  ${e.number}\n$what"
                setPadding(0, 12, 0, 12)
            })
        }
    }

    private fun refresh() {
        listBox.removeAllViews()
        store.rules().forEach { r ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply {
                text = r.number + "\n" + replyNames[r.replyFrom + 1] +
                    if (r.message.isNotBlank()) "\n« ${r.message} »" else ""
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            row.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    store.saveRules(store.rules().filter { it.number != r.number })
                    refresh()
                }
            })
            listBox.addView(row)
        }
    }

    private fun askPermissions() {
        val need = arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_PHONE_STATE,
            "android.permission.POST_NOTIFICATIONS"
        ).filter { it != "android.permission.POST_NOTIFICATIONS" || android.os.Build.VERSION.SDK_INT >= 33 }
         .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) toast("الصلاحيات متاحة بالفعل")
        else requestPermissions(need.toTypedArray(), 1)
    }

    @Suppress("DEPRECATION")
    private fun askRole() {
        val rm = getSystemService(RoleManager::class.java)
        when {
            rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) -> toast("مفعّل بالفعل")
            rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) ->
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 2)
            else -> toast("الميزة غير متاحة على الجهاز")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
