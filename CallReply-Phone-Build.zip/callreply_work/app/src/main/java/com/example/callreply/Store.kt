package com.example.callreply

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** replyFrom: -1 = نفس الخط اللي اتصل عليه، 0 = الخط 1، 1 = الخط 2 */
data class LogEntry(val time: Long, val number: String, val line: Int, val event: String, val detail: String)

data class Rule(val number: String, val message: String, val replyFrom: Int = -1)

fun normalize(n: String): String = n.filter { it.isDigit() }.takeLast(9)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var defaultMessage: String
        get() = p.getString("msg", "أنا مشغول دلوقتي، هكلمك بعدين.")!!
        set(v) = p.edit().putString("msg", v).apply()

    var cooldownMin: Int
        get() = p.getInt("cd", 60)
        set(v) = p.edit().putInt("cd", v).apply()

    /** الخط المرسِل العام: -1 = نفس الخط اللي اتصل عليه، 0 = الخط 1، 1 = الخط 2 */
    var senderSlot: Int
        get() = p.getInt("sender", -1)
        set(v) = p.edit().putInt("sender", v).apply()

    var smsEnabled: Boolean
        get() = p.getBoolean("sms_on", true)
        set(v) = p.edit().putBoolean("sms_on", v).apply()

    var waNotify: Boolean
        get() = p.getBoolean("wa_on", false)
        set(v) = p.edit().putBoolean("wa_on", v).apply()

    var countryCode: String
        get() = p.getString("cc", "20")!!
        set(v) = p.edit().putString("cc", v.filter { it.isDigit() }).apply()

    // السجل (آخر 200 حدث)
    fun addLog(e: LogEntry) {
        val arr = JSONArray(p.getString("log", "[]"))
        val out = JSONArray()
        out.put(JSONObject().put("t", e.time).put("n", e.number).put("l", e.line)
            .put("e", e.event).put("d", e.detail))
        for (i in 0 until minOf(arr.length(), 199)) out.put(arr.get(i))
        p.edit().putString("log", out.toString()).apply()
    }

    fun logs(): List<LogEntry> {
        val arr = JSONArray(p.getString("log", "[]"))
        return List(arr.length()) {
            val o = arr.getJSONObject(it)
            LogEntry(o.getLong("t"), o.getString("n"), o.getInt("l"), o.getString("e"), o.optString("d"))
        }
    }

    fun clearLogs() = p.edit().remove("log").apply()

    // إعدادات كل خط (slot 0 و 1)
    fun simEnabled(slot: Int) = p.getBoolean("sim_on_$slot", true)
    fun setSimEnabled(slot: Int, v: Boolean) = p.edit().putBoolean("sim_on_$slot", v).apply()
    fun simMessage(slot: Int): String = p.getString("sim_msg_$slot", "")!!
    fun setSimMessage(slot: Int, v: String) = p.edit().putString("sim_msg_$slot", v).apply()

    fun rules(): MutableList<Rule> {
        val arr = JSONArray(p.getString("rules", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Rule(o.getString("n"), o.optString("m", ""), o.optInt("f", -1))
        }
    }

    fun saveRules(list: List<Rule>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("n", it.number).put("m", it.message).put("f", it.replyFrom))
        }
        p.edit().putString("rules", arr.toString()).apply()
    }

    fun findRule(number: String): Rule? {
        val key = normalize(number)
        if (key.isEmpty()) return null
        return rules().firstOrNull { normalize(it.number) == key }
    }

    fun lastSent(number: String): Long = p.getLong("last_" + normalize(number), 0L)
    fun markSent(number: String) =
        p.edit().putLong("last_" + normalize(number), System.currentTimeMillis()).apply()
}
