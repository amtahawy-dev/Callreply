package com.example.callreply

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.PhoneAccountHandle
import android.telephony.SmsManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.util.Log

class CallScreener : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        val allow = CallResponse.Builder().build()

        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, allow); return
        }

        val number = details.handle?.schemeSpecificPart
        val store = Store(this)

        // الخط اللي المكالمة جت عليه
        val incoming = lineOf(details.accountHandle)
        val slot = incoming?.simSlotIndex
        if (slot != null && !store.simEnabled(slot)) {
            respondToCall(details, allow); return
        }

        val rule = number?.let { store.findRule(it) }
        if (number == null || rule == null) {
            respondToCall(details, allow); return
        }

        respondToCall(
            details,
            CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(false)
                .build()
        )

        val now = System.currentTimeMillis()
        store.addLog(LogEntry(now, number, slot ?: -1, "rejected", ""))

        // الأولوية: رسالة الرقم ← رسالة الخط ← الرسالة الافتراضية
        val text = rule.message
            .ifBlank { slot?.let { store.simMessage(it) } ?: "" }
            .ifBlank { store.defaultMessage }

        if (store.smsEnabled) {
            val gap = store.cooldownMin * 60_000L
            if (now - store.lastSent(number) >= gap) {
                val subId = pickSubId(rule.replyFrom, store.senderSlot, incoming)
                if (sendSms(number, text, subId)) {
                    store.markSent(number)
                    val from = subs().firstOrNull { it.subscriptionId == subId }?.simSlotIndex
                    store.addLog(LogEntry(now, number, from ?: -1, "sms_sent", ""))
                } else {
                    store.addLog(LogEntry(now, number, -1, "sms_failed", ""))
                }
            } else {
                store.addLog(LogEntry(now, number, -1, "cooldown", ""))
            }
        }

        if (store.waNotify) {
            try {
                Notifier.post(this, number, text, store.countryCode)
                store.addLog(LogEntry(now, number, -1, "wa_notified", ""))
            } catch (e: Exception) {
                Log.e("CallReply", "WA notification failed", e)
            }
        }
    }

    private fun subs(): List<SubscriptionInfo> = try {
        getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList ?: emptyList()
    } catch (e: SecurityException) {
        emptyList()
    }

    private fun lineOf(h: PhoneAccountHandle?): SubscriptionInfo? {
        if (h == null) return null
        val list = subs()
        list.firstOrNull { it.iccId == h.id || it.subscriptionId.toString() == h.id }
            ?.let { return it }
        if (Build.VERSION.SDK_INT >= 30) {
            val id = try {
                getSystemService(TelephonyManager::class.java)
                    .createForPhoneAccountHandle(h)?.subscriptionId
            } catch (e: Exception) { null }
            return list.firstOrNull { it.subscriptionId == id }
        }
        return null
    }

    // الأولوية: إعداد الرقم ← الخط المرسِل العام ← نفس الخط اللي اتصل عليه
    private fun pickSubId(replyFrom: Int, sender: Int, incoming: SubscriptionInfo?): Int? {
        val want = if (replyFrom >= 0) replyFrom else sender
        if (want >= 0) {
            subs().firstOrNull { it.simSlotIndex == want }?.let { return it.subscriptionId }
        }
        return incoming?.subscriptionId
    }

    @Suppress("DEPRECATION")
    private fun sendSms(to: String, text: String, subId: Int?): Boolean = try {
        val sms: SmsManager = when {
            subId == null ->
                if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java)
                else SmsManager.getDefault()
            Build.VERSION.SDK_INT >= 31 ->
                getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
            else -> SmsManager.getSmsManagerForSubscriptionId(subId)
        }
        sms.sendMultipartTextMessage(to, null, sms.divideMessage(text), null, null)
        true
    } catch (e: Exception) {
        Log.e("CallReply", "SMS failed", e)
        false
    }
}
