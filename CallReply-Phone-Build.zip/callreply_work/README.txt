خطوات التشغيل:
1) Android Studio > New Project > Empty Views Activity (Kotlin)، الـ package: com.example.callreply، Min SDK 29.
2) انسخ الملفات دي مكان الموجودة (app/build.gradle.kts و AndroidManifest.xml و ملفات Kotlin). امسح activity_main.xml لو اتولّد ومش محتاجه.
3) شغّل على موبايلك (USB debugging).
4) من التطبيق: اضغط "إعطاء الصلاحيات" ثم "تفعيل كمُصفّي مكالمات"، وضيف الأرقام.
ملاحظات: استثني التطبيق من توفير البطارية (خصوصاً شاومي/سامسونج/أوبو)، واختبر برقم تاني يتصل بيك.
