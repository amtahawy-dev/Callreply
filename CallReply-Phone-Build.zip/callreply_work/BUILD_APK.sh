#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then echo 'ERROR: Java is not installed.' >&2; exit 1; fi
if ! command -v gradle >/dev/null 2>&1; then echo 'ERROR: Gradle is not on PATH. Open the project in Android Studio and build using Build > Build APK(s).' >&2; exit 1; fi
gradle --no-daemon :app:assembleDebug
echo "APK: $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
